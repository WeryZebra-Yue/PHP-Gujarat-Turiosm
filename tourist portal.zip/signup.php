<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gujarat Tourism</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Carrois+Gothic+SC&family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="login-signup.css" />
</head>

<body>
    <div class="loginback">
        <div class="loginbox">
            <div class="logintext">Sign up</div>
            <form method="post">
                <input class="textbox" type="text" name="fname" placeholder="First Name" />
                <input class="textbox" type="text" name="lname" placeholder="Last Name" />
                <input class="textbox" type="text" onblur="(this.type='text')" onfocus="(this.type='date')" name="bdate" placeholder="Birthdate" />
                <input class="textbox" type="email" name="email" placeholder="Email" />
                <input class="textbox" type="password" name="password" placeholder="Password" />
                <input class="textbox" type="password" name="cpassword" placeholder="Confirm Password" />
                <input id="signup" class="btn" type="submit" name="submit" value="Sign up" />
            </form>
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "tour";
            if(isset($_POST['submit'])){
                $fname = $_POST["fname"];
                $lname = $_POST["lname"];
                $birthdate=$_POST["bdate"];
                $email = $_POST["email"];
                $cpassword=$_POST["cpassword"];

                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("connection failed: " . $conn->connect_error);
                }

                $sql = "INSERT INTO users(firstname, lastname, birthdate, email, cpassword) VALUES('$fname', '$lname','$birthdate','$email','$cpassword')";

                if ($conn->query($sql) === TRUE) {
                    $last_id = $conn->insert_id;
                    echo "New record created successfully. last inserted id is:" . $last_id;
                } else {
                    echo "Error: " . $sql . "<br> " . $conn->error;
                }
                $conn->close();
            }
            ?>

        </div>
        <div class="loginbox2">
            <p class="linktext">have an account? <a class="link" href="login.php">Log in</a></p>
        </div>
    </div>
    </div>

</body>

</html>