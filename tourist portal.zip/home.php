<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Home</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="home.css" />
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
</head>

<body>
    <div class="navbar">
        <div class="navlogo"></div>
        <div class="navbuttons">
            <ul>
                <a href="#home">Home</a>
            </ul>
            <ul>
                <a href="#places">Places</a>
            </ul>
            <ul>
                <a href="#about">About Us</a>
            </ul>
            <ul>
                <a href="#contact">Contact Us</a>
            </ul>
        </div>
    </div>
    <div id="home">
        <span class="quote">"નમસ્કાર, ગુજરાતમાં આપનું સ્વાગત છે"

        <?php 
            $counter = 0;
            if(isset($_COOKIE['counter'])){

                $counter = $_COOKIE['counter'];
                $counter++;
                $_COOKIE['counter'] = $counter;
                setcookie('counter', $counter);

            }
            else{
                $_COOKIE['counter'] = 1;
                setcookie('counter', 1);
            }
            echo "<br/>Visitors: $counter";
        ?>
        </span>
    </div>
    <div id="places">
        <a href="https://www.youtube.com/watch?v=TNTnEbR_m8w" class="placebox">
            <div id="photo6" class="photo"></div><span>Statue of Unity</span>
        </a>
        <a href="https://www.youtube.com/watch?v=2SjWraA4Wro" class="placebox">
            <div id="photo3" class="photo"></div><span>Saputara</span>
        </a>
        <a href="https://www.youtube.com/watch?v=CtHaI7ONAiM" class="placebox">
            <div id="photo4" class="photo"></div><span>Modhera</span>
        </a>
        <a href="https://www.youtube.com/watch?v=w4ra7Iuc_3U" class="placebox">
            <div id="photo1" class="photo" href=""></div><span>Vadodara</span>
        </a>
        <a href="https://www.youtube.com/watch?v=MOXZ6TH11GY" class="placebox">
            <div id="photo5" class="photo"></div><span>Kutch</span>
        </a>
        <a href="https://www.youtube.com/watch?v=4dbkKjPuM_w" class="placebox">
            <div id="photo7" class="photo"></div><span>Dwarka</span>
        </a>
        <a href="https://www.youtube.com/watch?v=JI1I1U83vZc" class="placebox">
            <div id="photo2" class="photo"></div><span>Diu</span>
        </a>
        <a href="https://www.youtube.com/watch?v=mdomTf2qjKE" class="placebox">
            <div id="photo8" class="photo"></div><span>Champaner</span>
        </a>
    </div>

    <div id="contact">
        <div id="about">
            <p class="heading">About Us</p>
            <p class="about"></p>Formed in 1978, the Tourism
            Corporation of Gujarat Ltd (TCGL) provides comprehensive travel
            assistance and services to the tourists coming to visit Gujarat. Some of the services of TCGL include
            accommodation, conducted tours and ground transport with a wide range of choice to meet diverse needs.
            </p>
        </div>

        <div class="menu">
            <span class="heading">Menu</span>
            <a href="#home">Home</a><a href="#places">Places</a><a href="#about">About Us</a><a href="#contact">Contact
                Us</a>
        </div>
        <div class="getintouch">
            <span class="heading"> Get in touch</span>
            <ul>Mobile: +91 9517538523</ul>
            <ul>Email: info@gujarattourism.com</ul>
            <ul>Office: Udyog Bhavan, Gandhinagar</ul>
        </div>
    </div>

</html>